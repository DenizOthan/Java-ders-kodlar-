# advancedJavaScript
Base repository for Siemens Advanced JS Course
